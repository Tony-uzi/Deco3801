from collections import deque

def bfs_grid(grid, start, target):
    """
    Performs a BFS search in a grid from the start point to the target point.

    Args:
        grid: A 2D list of integers representing the grid, where 0s are empty cells and 1s are obstacles.
        start: A tuple (x, y) representing the starting point.
        target: A tuple (x, y) representing the target point.

    Returns:
        A list of tuples representing the shortest path from the start point to the target point, or None if no path is found.
    """
    rows, cols = len(grid), len(grid[0])
    visited = [[False for _ in range(cols)] for _ in range(rows)]
    queue = deque([(start, [start])])  # (point, path)

    while queue:
        point, path = queue.popleft()
        x, y = point
        if point == target:
            return path
        if visited[x][y]:
            continue
        visited[x][y] = True

        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:  # right, left, down, up
            nx, ny = x + dx, y + dy
            if 0 <= nx < rows and 0 <= ny < cols and grid[nx][ny] == 0 and not visited[nx][ny]:
                queue.append(((nx, ny), path + [(nx, ny)]))

    return None
