import numpy as np


def do_mapping(row: int, col: int):
    # Open the file for reading
    with open("map.text", "r") as file:
        # Initialize the 2D list with the given dimensions
        list_of_map = [[None for _ in range(col)] for _ in range(row)]

        # Iterate over each line and each character
        r = 0  # Row index
        for line in file:
            c = 0  # Column index
            for char in line.strip():  # strip() to remove any trailing newline
                if r < row and c < col:  # Ensure we don't go out of bounds
                    list_of_map[r][c] = char
                c += 1
            r += 1
            if r >= row:
                break  # Stop if we've filled the required rows

    return list_of_map


def do_processing(map_process: list):
    start = None
    end = None

    # Find the start and end points
    for r in range(len(map_list)):
        for c in range(len(map_list[0])):
            if map_list[r][c] == 'S':
                start = (r, c)
            elif map_list[r][c] == 'E':
                end = (r, c)


if __name__ == '__main__':

    size = open("size.txt", "r")
    row = int(size.readline().strip())
    col = int(size.readline())
    map_list = do_mapping(row, col)
    do_processing(map_list)