Built automatically by sprites/belt/generate_wire_sprites.js
